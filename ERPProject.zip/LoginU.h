//---------------------------------------------------------------------------

#ifndef LoginUH
#define LoginUH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
//---------------------------------------------------------------------------
#include "ObjectU.h"
//---------------------------------------------------------------------------
#include "cxButtons.hpp"
#include "cxGraphics.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "cxLookAndFeels.hpp"
#include "dxSkinBlack.hpp"
#include "dxSkinBlue.hpp"
#include "dxSkinBlueprint.hpp"
#include "dxSkinCaramel.hpp"
#include "dxSkinCoffee.hpp"
#include "dxSkinDarkRoom.hpp"
#include "dxSkinDarkSide.hpp"
#include "dxSkinDevExpressDarkStyle.hpp"
#include "dxSkinDevExpressStyle.hpp"
#include "dxSkinFoggy.hpp"
#include "dxSkinGlassOceans.hpp"
#include "dxSkinHighContrast.hpp"
#include "dxSkiniMaginary.hpp"
#include "dxSkinLilian.hpp"
#include "dxSkinLiquidSky.hpp"
#include "dxSkinLondonLiquidSky.hpp"
#include "dxSkinMcSkin.hpp"
#include "dxSkinMetropolis.hpp"
#include "dxSkinMetropolisDark.hpp"
#include "dxSkinMoneyTwins.hpp"
#include "dxSkinOffice2007Black.hpp"
#include "dxSkinOffice2007Blue.hpp"
#include "dxSkinOffice2007Green.hpp"
#include "dxSkinOffice2007Pink.hpp"
#include "dxSkinOffice2007Silver.hpp"
#include "dxSkinOffice2010Black.hpp"
#include "dxSkinOffice2010Blue.hpp"
#include "dxSkinOffice2010Silver.hpp"
#include "dxSkinOffice2013DarkGray.hpp"
#include "dxSkinOffice2013LightGray.hpp"
#include "dxSkinOffice2013White.hpp"
#include "dxSkinPumpkin.hpp"
#include "dxSkinsCore.hpp"
#include "dxSkinsDefaultPainters.hpp"
#include "dxSkinSeven.hpp"
#include "dxSkinSevenClassic.hpp"
#include "dxSkinSharp.hpp"
#include "dxSkinSharpPlus.hpp"
#include "dxSkinSilver.hpp"
#include "dxSkinSpringTime.hpp"
#include "dxSkinStardust.hpp"
#include "dxSkinSummer2008.hpp"
#include "dxSkinTheAsphaltWorld.hpp"
#include "dxSkinValentine.hpp"
#include "dxSkinVisualStudio2013Blue.hpp"
#include "dxSkinVisualStudio2013Dark.hpp"
#include "dxSkinVisualStudio2013Light.hpp"
#include "dxSkinVS2010.hpp"
#include "dxSkinWhiteprint.hpp"
#include "dxSkinXmas2008Blue.hpp"
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Mask.hpp>
#include <Vcl.Menus.hpp>
#include "TadCommon.h"
#include "TadDatabase.h"
#include "TadFileLogger.h"
#include "dxGDIPlusClasses.hpp"
#include <Vcl.ImgList.hpp>
#include "cxContainer.hpp"
#include "cxControls.hpp"
#include "cxEdit.hpp"
#include "cxMaskEdit.hpp"
#include "cxSpinEdit.hpp"
#include "cxTextEdit.hpp"
#include "cxImage.hpp"
//---------------------------------------------------------------------------
const int iCountValue = 4;
//---------------------------------------------------------------------------
class TLoginF : public TForm
{
__published:	// IDE-managed Components
	TPanel *pnDatabase;
	TLabel *Label1;
	TLabel *lbDBNameT;
	TMaskEdit *edDBUserV;
	TLabel *lbDBUserT;
	TLabel *lbDBPasswdT;
	TLabel *lbDBSessionCntT;
	TLabel *lbDBSessionChkT;
	TMaskEdit *edDBPasswdV;
	TcxButton *btnSave;
	TPanel *pnDatabaseState;
	TLabel *lbDBConnCntT;
	TLabel *Label8;
	TLabel *lbDBQueueCntT;
	TLabel *lbDBConnCntV;
	TLabel *lbDBQueueCntV;
	TTimer *tmMain;
	TadFileLogger *adFileLogger1;
	TadDatabase *adDatabase1;
	TcxImageList *cxImageList1;
	TPanel *Panel3;
	TcxButton *cxButton2;
	TPanel *Panel4;
	TImage *Image1;
	TcxButton *btMain;
	TcxSpinEdit *edDBSessionCntV;
	TcxSpinEdit *edDBSessionChkV;
	TPanel *pnLogin;
	TLabel *Label2;
	TMaskEdit *edUsername;
	TMaskEdit *edPassword;
	TLabel *Label3;
	TcxImage *imLogin;
	TcxImage *cxImage2;
	TcxImage *cxImage3;
	TMaskEdit *edDBNameV;
	void __fastcall cxButton2Click(TObject *Sender);
	void __fastcall btMainClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall Panel3MouseMove(TObject *Sender, TShiftState Shift, int X,
          int Y);
	void __fastcall imLoginClick(TObject *Sender);
	void __fastcall cxImage2Click(TObject *Sender);
	void __fastcall cxImage3Click(TObject *Sender);
	void __fastcall tmMainTimer(TObject *Sender);
	void __fastcall FormShow(TObject *Sender);
	void __fastcall btnSaveClick(TObject *Sender);
	void __fastcall edUsernameKeyPress(TObject *Sender, System::WideChar &Key);
	void __fastcall edPasswordKeyPress(TObject *Sender, System::WideChar &Key);


private:
	TApplicationInfo *m_pAppInfo;
	TadFileLogger	 *m_pFileLogger;
	TadDatabase		 *m_pDatabase;
	int m_iDBQueue;
	int iKeyCount;
	int iLockCount;
	int *p_iExit;           // ������ ���� üũ ������
	int iExit, iLogin, iLogout;
private:
	void __fastcall fnWriteAppStatus(UnicodeString a_sMsg);
	void __fastcall fnWriteFileLog(UnicodeString a_sLogMsg);
	void  __fastcall fnFileLoggerStop(TObject *Sender);

	void __fastcall fnOnDatabaseAfterStopped(TObject *a_pSender);
	void __fastcall fnOnDatabaseConnected(TObject *a_pSender, int a_iSessionNo);
	void __fastcall fnOnDatabaseDisconnected(TObject *a_pSender, int a_iSessionNo);
	void __fastcall fnProcDBResponse(TMessage a_stMsg);
	void __fastcall fnLoginCheck(TadResQuery *a_pResQry);
//	void __fastcall fnGetSensorInfo(TadResQuery *a_pResQry);
public:		// User declarations
	__fastcall TLoginF(TComponent* Owner);
	__fastcall ~TLoginF();





BEGIN_MESSAGE_MAP
	VCL_MESSAGE_HANDLER(WM_DB_RESPONSE, TMessage, fnProcDBResponse);
END_MESSAGE_MAP(TForm);

};
//---------------------------------------------------------------------------
extern PACKAGE TLoginF *LoginF;
//---------------------------------------------------------------------------
#endif
