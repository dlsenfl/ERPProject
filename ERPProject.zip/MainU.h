//---------------------------------------------------------------------------

#ifndef MainUH
#define MainUH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include "cxButtons.hpp"
#include "cxGraphics.hpp"
#include "cxLookAndFeelPainters.hpp"
#include "cxLookAndFeels.hpp"
#include "dxSkinBlack.hpp"
#include "dxSkinBlue.hpp"
#include "dxSkinBlueprint.hpp"
#include "dxSkinCaramel.hpp"
#include "dxSkinCoffee.hpp"
#include "dxSkinDarkRoom.hpp"
#include "dxSkinDarkSide.hpp"
#include "dxSkinDevExpressDarkStyle.hpp"
#include "dxSkinDevExpressStyle.hpp"
#include "dxSkinFoggy.hpp"
#include "dxSkinGlassOceans.hpp"
#include "dxSkinHighContrast.hpp"
#include "dxSkiniMaginary.hpp"
#include "dxSkinLilian.hpp"
#include "dxSkinLiquidSky.hpp"
#include "dxSkinLondonLiquidSky.hpp"
#include "dxSkinMcSkin.hpp"
#include "dxSkinMetropolis.hpp"
#include "dxSkinMetropolisDark.hpp"
#include "dxSkinMoneyTwins.hpp"
#include "dxSkinOffice2007Black.hpp"
#include "dxSkinOffice2007Blue.hpp"
#include "dxSkinOffice2007Green.hpp"
#include "dxSkinOffice2007Pink.hpp"
#include "dxSkinOffice2007Silver.hpp"
#include "dxSkinOffice2010Black.hpp"
#include "dxSkinOffice2010Blue.hpp"
#include "dxSkinOffice2010Silver.hpp"
#include "dxSkinOffice2013DarkGray.hpp"
#include "dxSkinOffice2013LightGray.hpp"
#include "dxSkinOffice2013White.hpp"
#include "dxSkinPumpkin.hpp"
#include "dxSkinsCore.hpp"
#include "dxSkinsDefaultPainters.hpp"
#include "dxSkinSeven.hpp"
#include "dxSkinSevenClassic.hpp"
#include "dxSkinSharp.hpp"
#include "dxSkinSharpPlus.hpp"
#include "dxSkinSilver.hpp"
#include "dxSkinSpringTime.hpp"
#include "dxSkinStardust.hpp"
#include "dxSkinSummer2008.hpp"
#include "dxSkinTheAsphaltWorld.hpp"
#include "dxSkinValentine.hpp"
#include "dxSkinVisualStudio2013Blue.hpp"
#include "dxSkinVisualStudio2013Dark.hpp"
#include "dxSkinVisualStudio2013Light.hpp"
#include "dxSkinVS2010.hpp"
#include "dxSkinWhiteprint.hpp"
#include "dxSkinXmas2008Blue.hpp"
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Menus.hpp>
#include <Vcl.ImgList.hpp>
#include "dxGDIPlusClasses.hpp"
#include "cxClasses.hpp"
#include "cxControls.hpp"
#include "dxRibbon.hpp"
#include "dxRibbonCustomizationForm.hpp"
#include "dxRibbonSkins.hpp"
#include "dxSkinsdxRibbonPainter.hpp"
#include "dxBar.hpp"
#include "dxSkinsdxBarPainter.hpp"
#include "cxContainer.hpp"
#include "cxEdit.hpp"
#include "cxImage.hpp"
#include <Vcl.Mask.hpp>
#include "cxCustomData.hpp"
#include "cxData.hpp"
#include "cxDataStorage.hpp"
#include "cxDBData.hpp"
#include "cxFilter.hpp"
#include "cxGrid.hpp"
#include "cxGridCustomTableView.hpp"
#include "cxGridCustomView.hpp"
#include "cxGridDBTableView.hpp"
#include "cxGridLevel.hpp"
#include "cxGridTableView.hpp"
#include "cxNavigator.hpp"
#include "cxStyles.hpp"
#include "dxSkinscxPCPainter.hpp"
#include <Data.DB.hpp>
#include <Vcl.ComCtrls.hpp>

//---------------------------------------------------------------------------
class TMainF : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TcxButton *cxButton1;
	TcxButton *cxButton2;
	TcxButton *cxButton3;
	TcxImageList *cxImageList1;
	TPanel *Panel2;
	TImage *Image1;
	TdxRibbonTab *dxRibbon1Tab1;
	TdxRibbon *dxRibbon1;
	TdxBarManager *dxBarManager1;
	TdxBarLargeButton *dxBarLargeButton1;
	TdxBarLargeButton *dxBarLargeButton2;
	TdxBarLargeButton *dxBarLargeButton3;
	TdxBarLargeButton *dxBarLargeButton4;
	TdxBarLargeButton *dxBarLargeButton5;
	TdxBarLargeButton *dxBarLargeButton6;
	TdxBarLargeButton *dxBarLargeButton7;
	TdxBarLargeButton *dxBarLargeButton8;
	TdxBarLargeButton *dxBarLargeButton9;
	TdxBar *dxBarManager1Bar1;
	TdxBarLargeButton *dxBarLargeButton10;
	TdxBarLargeButton *dxBarLargeButton11;
	TdxBarLargeButton *dxBarLargeButton12;
	TdxBarLargeButton *dxBarLargeButton13;
	TdxBarLargeButton *dxBarLargeButton14;
	TdxBarLargeButton *dxBarLargeButton15;
	TdxBarLargeButton *dxBarLargeButton16;
	TdxBarLargeButton *dxBarLargeButton17;
	TdxBarLargeButton *dxBarLargeButton18;
	TdxBarLargeButton *dxBarLargeButton19;
	TdxBarLargeButton *dxBarLargeButton20;
	TcxButton *btLogout;
	TPanel *pnShowGrid;
	TPanel *pnMain;
	void __fastcall cxButton1Click(TObject *Sender);
	void __fastcall cxButton2Click(TObject *Sender);
	void __fastcall cxButton3Click(TObject *Sender);
	void __fastcall Panel1MouseMove(TObject *Sender, TShiftState Shift, int X,
		  int Y);
	void __fastcall Panel1DblClick(TObject *Sender);
	void __fastcall btItemRegClick(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall dxBarLargeButton10Click(TObject *Sender);
	void __fastcall dxBarLargeButton13Click(TObject *Sender);
	void __fastcall dxBarLargeButton14Click(TObject *Sender);
	void __fastcall dxBarLargeButton15Click(TObject *Sender);
	void __fastcall dxBarLargeButton16Click(TObject *Sender);
	void __fastcall dxBarLargeButton17Click(TObject *Sender);
	void __fastcall dxBarLargeButton19Click(TObject *Sender);
	void __fastcall dxBarLargeButton20Click(TObject *Sender);
	void __fastcall btLogoutClick(TObject *Sender);
private:	// User declarations
	void __fastcall CreateParams(TCreateParams& Params);
//	void __fastcall WndProc(TMessage &M);
private:
	int *p_iExit;
	int iExit, iLogin, iLogout;
public:		// User declarations
	__fastcall  TMainF(TComponent* Owner);
	__fastcall ~TMainF();

	__property int *Exit = {read=p_iExit, write=p_iExit};
};
//---------------------------------------------------------------------------
extern PACKAGE TMainF *MainF;
//---------------------------------------------------------------------------
#endif
