//---------------------------------------------------------------------------

#pragma hdrstop

#include "ObjectU.h"
#include <IniFiles.hpp>
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
__fastcall 	TApplicationInfo::TApplicationInfo()
	: TadAppConfig()
{
	m_dwFileLoggerID = 0;
	m_dwACPM		 = 0;
	m_dwDBPM		 = 0;
}
//---------------------------------------------------------------------------
__fastcall 	TApplicationInfo::~TApplicationInfo()
{

}
//---------------------------------------------------------------------------
bool __fastcall TApplicationInfo::fnLoadConfig(void)
{
	fnLoadFromFile(m_sFileName);
}
//---------------------------------------------------------------------------

bool __fastcall TApplicationInfo::fnSaveConfig(void)
{
	fnInitialize();                                      //	???????

	return fnSaveToFile(m_sFileName);                    // �������� ������ config.tmp���Ϸ� ����������
}
//---------------------------------------------------------------------------
