//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "LoginU.h"
#include "MainU.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxGraphics"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxLookAndFeels"
#pragma link "dxSkinBlack"
#pragma link "dxSkinBlue"
#pragma link "dxSkinBlueprint"
#pragma link "dxSkinCaramel"
#pragma link "dxSkinCoffee"
#pragma link "dxSkinDarkRoom"
#pragma link "dxSkinDarkSide"
#pragma link "dxSkinDevExpressDarkStyle"
#pragma link "dxSkinDevExpressStyle"
#pragma link "dxSkinFoggy"
#pragma link "dxSkinGlassOceans"
#pragma link "dxSkinHighContrast"
#pragma link "dxSkiniMaginary"
#pragma link "dxSkinLilian"
#pragma link "dxSkinLiquidSky"
#pragma link "dxSkinLondonLiquidSky"
#pragma link "dxSkinMcSkin"
#pragma link "dxSkinMetropolis"
#pragma link "dxSkinMetropolisDark"
#pragma link "dxSkinMoneyTwins"
#pragma link "dxSkinOffice2007Black"
#pragma link "dxSkinOffice2007Blue"
#pragma link "dxSkinOffice2007Green"
#pragma link "dxSkinOffice2007Pink"
#pragma link "dxSkinOffice2007Silver"
#pragma link "dxSkinOffice2010Black"
#pragma link "dxSkinOffice2010Blue"
#pragma link "dxSkinOffice2010Silver"
#pragma link "dxSkinOffice2013DarkGray"
#pragma link "dxSkinOffice2013LightGray"
#pragma link "dxSkinOffice2013White"
#pragma link "dxSkinPumpkin"
#pragma link "dxSkinsCore"
#pragma link "dxSkinsDefaultPainters"
#pragma link "dxSkinSeven"
#pragma link "dxSkinSevenClassic"
#pragma link "dxSkinSharp"
#pragma link "dxSkinSharpPlus"
#pragma link "dxSkinSilver"
#pragma link "dxSkinSpringTime"
#pragma link "dxSkinStardust"
#pragma link "dxSkinSummer2008"
#pragma link "dxSkinTheAsphaltWorld"
#pragma link "dxSkinValentine"
#pragma link "dxSkinVisualStudio2013Blue"
#pragma link "dxSkinVisualStudio2013Dark"
#pragma link "dxSkinVisualStudio2013Light"
#pragma link "dxSkinVS2010"
#pragma link "dxSkinWhiteprint"
#pragma link "dxSkinXmas2008Blue"
#pragma link "TadCommon"
#pragma link "TadDatabase"
#pragma link "TadFileLogger"
#pragma link "dxGDIPlusClasses"
#pragma link "cxContainer"
#pragma link "cxControls"
#pragma link "cxEdit"
#pragma link "cxMaskEdit"
#pragma link "cxSpinEdit"
#pragma link "cxTextEdit"
#pragma link "cxImage"
#pragma resource "*.dfm"
TLoginF *LoginF;
//---------------------------------------------------------------------------
__fastcall TLoginF::TLoginF(TComponent* Owner)
	: TForm(Owner)
{
	iExit=0, iLogin=1, iLogout=2;
	p_iExit = new int();
	m_pAppInfo = new TApplicationInfo();
	m_pAppInfo->fnLoadConfig();					// �������� �ε�

	m_pFileLogger		 = new TadFileLogger(NULL);
	m_pFileLogger->MQMgr = m_pAppInfo->MQMgr;
//	m_pFileLogger->OnStop = fnFileLoggerStop;

	m_pDatabase			 		      = new TadDatabase(NULL);
	m_pDatabase->MQMgr	 		      = m_pAppInfo->MQMgr;
	m_pDatabase->FileLoggerID	      = m_pAppInfo->FileLoggerID;
	m_pDatabase->DatabaseKind	      = dbkMYSQL;
	m_pDatabase->DatabaseName	      = m_pAppInfo->DB_ServerName;
	m_pDatabase->UserName		      = m_pAppInfo->DB_UserName;
	m_pDatabase->Password		      = m_pAppInfo->DB_Password;
	m_pDatabase->MinSessionCount      = m_pAppInfo->DB_MinSessionCnt;
	m_pDatabase->MaxSessionCount      = m_pAppInfo->DB_MaxSessionCnt;
	m_pDatabase->MessageResponse      = WM_DB_RESPONSE;
	m_pDatabase->MessageResult	      = WM_DB_RESULT;

	m_pDatabase->OnAfterStopped	      = fnOnDatabaseAfterStopped;        // �����ͺ��̽��� ����ڿ� ȣ���� �Լ�
	m_pDatabase->OnDatabaseConnect    = fnOnDatabaseConnected;         // �����ͺ��̽��� ���� �Ǿ����� ȣ���� �Լ�
	m_pDatabase->OnDatabaseDisconnect = fnOnDatabaseDisconnected;      // �����ͺ��̽��� ������ �������� ȣ���� �Լ�

	m_iDBQueue 	= 0;

	iKeyCount 	= 0;
	iLockCount 	= 0;
	*p_iExit    = iLogin;

}
//---------------------------------------------------------------------------
__fastcall TLoginF::~TLoginF()
{
	delete m_pAppInfo;
//	delete m_pFileLogger;			// error????????
	delete m_pDatabase;

	delete p_iExit;
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::fnFileLoggerStop(TObject *Sender)
{

}
//---------------------------------------------------------------------------
void __fastcall TLoginF::fnWriteAppStatus(UnicodeString a_sMsg)
{
	TadLogFileInfo *pLFI;

	if(m_pAppInfo->FileLoggerID == 0) return;
	a_sMsg = L"[" + Now().FormatString(L"hh:nn:ss.zzz") + L"] " + a_sMsg + L"\r\n";
	pLFI = new TadLogFileInfo(m_pAppInfo->MQMgr);
	pLFI->FileName = L"APP_STATUS_" + Now().FormatString(L"hh") + ".log";
	pLFI->Text = a_sMsg;
	pLFI->fnWriteLogFile(m_pAppInfo->FileLoggerID);
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::fnWriteFileLog(UnicodeString a_sLogMsg)               // ??????  ���� �߻��� ȣ��
{
	try {
		HANDLE     	  hFile;
		DWORD      	  dwWriteSize;
		UnicodeString sFName;
		AnsiString    sMsg  = a_sLogMsg;
		TDateTime 	  dtNow = Now();

		sFName  = ExtractFilePath(Application->ExeName) + "LOG\\" + dtNow.FormatString("yyyy-mm-dd");
		sFName += "\\PROC_DEBUG_" + dtNow.FormatString("hh") + ".LOG";
		if((hFile = CreateFileW(sFName.c_str(),
							   GENERIC_READ|GENERIC_WRITE,
							   FILE_SHARE_READ,
							   NULL,
							   OPEN_ALWAYS,
							   FILE_ATTRIBUTE_NORMAL,
							   NULL)) == INVALID_HANDLE_VALUE) return;
		SetFilePointer(hFile, 0, NULL, FILE_END);

		sMsg = "[" + dtNow.FormatString("hh:nn:ss.zzz") + "] " + sMsg + "\r\n";
		WriteFile(hFile, sMsg.c_str(), sMsg.Length() * sMsg.ElementSize(), &dwWriteSize, NULL);
		CloseHandle(hFile);
	}
	catch ( const Sysutils::Exception &E ) {

	}
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::fnOnDatabaseAfterStopped(TObject *a_pSender)
{
	try {

	}catch(Exception &E){
		fnWriteAppStatus(L"OnDatabaseAfterStopped\r\n" + E.Message);
	}
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::fnOnDatabaseConnected(TObject *a_pSender, int a_iSessionNo)
{
	try {
		if(!m_pAppInfo->DBPM) {
			m_pAppInfo->DBPM = m_pDatabase->DatabaseProcessID;
		}

		lbDBConnCntV->Caption = IntToStr(m_pDatabase->ActiveSessionCount) + L" / " + IntToStr(m_pDatabase->MaxSessionCount);
		lbDBConnCntV->Update();
	}catch(Exception &E){
		fnWriteAppStatus(L"OnDatabaseConnected\r\n" + E.Message);
	}
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::fnOnDatabaseDisconnected(TObject *a_pSender, int a_iSessionNo)
{
	try {
		lbDBConnCntV->Caption = IntToStr(m_pDatabase->ActiveSessionCount) + L" / " + IntToStr(m_pDatabase->MaxSessionCount);
		lbDBConnCntV->Update();
	}catch(Exception &E){
		fnWriteAppStatus(L"ACPM OnDatabaseDisconnected\r\n" + E.Message);
	}
}
//---------------------------------------------------------------------------

void __fastcall TLoginF::FormShow(TObject *Sender)
{
	m_pFileLogger->BaseFilePath = GetCurrentDir();
	m_pFileLogger->Active		= true;
	m_pAppInfo->FileLoggerID	= m_pFileLogger->FileLoggerID; 		// �� ���� ���� �� �α��������� �� �α������ȿ� ���糯¥���� ����
	fnWriteAppStatus(L"MAIN : Start the FileLogger");
	Sleep(500);

	edDBNameV->Text		   = m_pAppInfo->DB_ServerName;
	edDBUserV->Text		   = m_pAppInfo->DB_UserName;
	edDBPasswdV->Text	   = m_pAppInfo->DB_Password;
	edDBSessionCntV->Value = m_pAppInfo->DB_MaxSessionCnt;
	edDBSessionChkV->Value = m_pAppInfo->DB_SessionChkInt;

	Left				   = m_pAppInfo->AppPosX;
	Top					   = m_pAppInfo->AppPosY;
	tmMain->Enabled 	   = true;                                  // Ÿ�̸� ����
	Sleep(300);      // �����ͺ��̽� �����Ŀ� �α��� ���� ��Ÿ������ ���ð� �߰�
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::tmMainTimer(TObject *Sender)
{
//	static bool bFirst = true;
	TDateTime dtCurr   = Now();

	if (m_pAppInfo->MQMgr->QueueCount > 30000) {                  // ????
		fnWriteFileLog("Message Queue Max.. (Quit)");

		UnicodeString sKill = "/t /f /im " + ExtractFileName(Application->ExeName);
		ShellExecute(NULL, L"open", L"taskKill.exe", sKill.c_str(), L"c:\\windows\\system32", SW_HIDE);
		Sleep(100);
	}

//	if (bFirst) {
//		bFirst = false;
		if(!m_pDatabase->DatabaseName.IsEmpty()){
			m_pDatabase->fnStart();                           // �����ͺ��̽� ����
		}
//	}

	m_iDBQueue = m_pDatabase->QueueCount;

	lbDBQueueCntV->Caption = IntToStr(m_iDBQueue) + L"EA";
	lbDBQueueCntV->Update();

	if(*p_iExit == iExit){
		Sleep(500);      			 			// ���� ���� Close()�Ϸ��ϵ��� sleep
		LoginF->Close();
	}else if(*p_iExit == iLogout){
		Sleep(500);
		*p_iExit = iLogin;
		edUsername->Text = "";
		edPassword->Text = "";
		LoginF->Show();
	}
//	tmMain->Enabled 	   = false;
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::cxButton2Click(TObject *Sender)
{
	LoginF->Close();
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::btMainClick(TObject *Sender)
{
	if(MainF == NULL){                                 // logout�� Error( MainF�� NULL�� �ƴ�???)
		MainF = new TMainF(NULL);
	}

	LoginF->Hide();
	MainF->Show();
	MainF->Exit = p_iExit;                        // ����Ȯ�� ������ ����

//	if(MainF->ShowModal() == mrOk){
//		LoginF->Close();
//	}else{
//		ShowMessage("Cancel");
//	}

//	LoginF->Close();
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::FormClose(TObject *Sender, TCloseAction &Action)
{
	m_pAppInfo->fnSaveConfig();
//	delete p_iExit;
//	Action = caFree;
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::FormDestroy(TObject *Sender)
{
//	LoginF = NULL;
}
//---------------------------------------------------------------------------

void __fastcall TLoginF::Panel3MouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y)
{
	ReleaseCapture();
	LoginF->Perform(WM_SYSCOMMAND, 0xf012,0);
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::imLoginClick(TObject *Sender)
{
	TadReqQuery *pReqQry;
	UnicodeString sSql;

	try{
		pReqQry = new TadReqQuery(m_pAppInfo->MQMgr);
		pReqQry->JobID     = 1000;
//		enum TadDBJobType     {djtSelect, djtInsert, djtUpdate, djtDelete, djtCancel, djtClear, djtInsertArray, djtTransaction};
		pReqQry->JobType   = djtSelect;
//		enum TadDBQueryType   {dqtExecute, dqtOpen};
		pReqQry->QueryType = dqtOpen;
		pReqQry->SQLFile   = GetCurrentDir() + "\\Sql\\User.sql";	// sql���� ��� ����

		pReqQry->FixedSession = false;
		pReqQry->NeedResponse = true;

		if(edUsername->Text.IsEmpty()){
			ShowMessage("���̵� �Է��ϼ���.");
			return;
		}else{
			if(edPassword->Text.IsEmpty()){
				ShowMessage("��й�ȣ�� �Է��ϼ���.");
				return;
			}else{
				sSql.sprintf(L"WHERE USER_ID = '%s' AND PASSWORD = '%s';",
									edUsername->Text, edPassword->Text);
			}
		}
		pReqQry->Variables->fnSetSQLVarByName("A1", sSql);

		pReqQry->fnSetFormHandle(Handle);
		pReqQry->fnSendRequest(m_pAppInfo->DBPM);       // ������ ��û
	}catch(Exception &E){
		fnWriteAppStatus(L"imLoginClick\r\n" + E.Message);
	}
//	btMainClick(Sender);
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::fnProcDBResponse(TMessage a_stMsg)
{
	UnicodeString sErrorLog;
	TadResQuery *pResQry;
	pResQry = (TadResQuery*)a_stMsg.WParam;

	try{
//		enum TadDBResult      {drFail, drSuccess, drUnknown};
		if(pResQry->Result == drSuccess){
			if(pResQry->JobID == 1000){
				fnLoginCheck(pResQry);
			}

		}else{
			sErrorLog  = "DB Result Error !! \r\n";
			sErrorLog += "==> Error Code : " + pResQry->ErrorCode + L"\r\n";
			sErrorLog += "==> Error Kind : " + IntToStr(pResQry->ErrorKind) + L"\r\n";
			sErrorLog += "==> Error Msg  : " + pResQry->ErrorMsg + L"\r\n";
			sErrorLog += "==> Error Msg  : " + pResQry->SQLText  + L"\r\n";
			sErrorLog += "DESCRIPTION : " + pResQry->Params->fnGetParamByNameStr("DESCRIPTION");
			fnWriteFileLog(sErrorLog);
		}
		delete pResQry;
	}catch(Exception &E){
		fnWriteAppStatus(L"ProcDBResponse\r\n" + E.Message);
	}
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::fnLoginCheck(TadResQuery *a_pResQry)
{
	if(a_pResQry->RecordCount){
		btMainClick(NULL);
	}else{
		ShowMessage("���̵� Ȥ�� ��й�ȣ�� ��ġ���� �ʽ��ϴ�.");
		edUsername->Text = "";
		edPassword->Text = "";
	}
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::cxImage2Click(TObject *Sender)
{
	if(iKeyCount == iCountValue){
		pnDatabase->Visible = true;
		pnLogin->Visible = false;
		iKeyCount = 0;

	}
	iKeyCount++;
}
//---------------------------------------------------------------------------
void __fastcall TLoginF::cxImage3Click(TObject *Sender)
{
	if(iLockCount == iCountValue){
		pnLogin->Visible = true;
		pnDatabase->Visible = false;
		iLockCount = 0;
	}
	iLockCount++;
}
//---------------------------------------------------------------------------

void __fastcall TLoginF::btnSaveClick(TObject *Sender)
{
	try{
		m_pAppInfo->DB_ServerName	 = edDBNameV->Text;
		m_pAppInfo->DB_UserName		 = edDBUserV->Text;
		m_pAppInfo->DB_Password		 = edDBPasswdV->Text;
		m_pAppInfo->DB_MaxSessionCnt = edDBSessionCntV->Value;
		m_pAppInfo->DB_SessionChkInt = edDBSessionChkV->Value;

		m_pAppInfo->AppPosX			 = Left;
		m_pAppInfo->AppPosY			 = Top;

		m_pAppInfo->fnSaveConfig();   	// �������� ������ config.tmp���Ϸ� ����������
	}catch(const Sysutils::Exception &E){

	}
}
//---------------------------------------------------------------------------

void __fastcall TLoginF::edUsernameKeyPress(TObject *Sender, System::WideChar &Key)

{
	if(Key == VK_RETURN){    		//����Ű�� ��������

		imLoginClick(Sender);

	}
}
//---------------------------------------------------------------------------

void __fastcall TLoginF::edPasswordKeyPress(TObject *Sender, System::WideChar &Key)

{
	if(Key == VK_RETURN){    		//����Ű�� ��������

		imLoginClick(Sender);

	}
}
//---------------------------------------------------------------------------

