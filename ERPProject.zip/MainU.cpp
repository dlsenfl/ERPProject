//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "MainU.h"
#include "ItemU.h"
#include "StockGridU.h"
#include "ReceiveGridU.h"
#include "ReleaseGridU.h"
#include "UsageGridU.h"
#include "RepairGridU.h"
#include "TempleGridU.h"
#include "ItemGridU.h"
#include "UserGridU.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "cxButtons"
#pragma link "cxGraphics"
#pragma link "cxLookAndFeelPainters"
#pragma link "cxLookAndFeels"
#pragma link "dxSkinBlack"
#pragma link "dxSkinBlue"
#pragma link "dxSkinBlueprint"
#pragma link "dxSkinCaramel"
#pragma link "dxSkinCoffee"
#pragma link "dxSkinDarkRoom"
#pragma link "dxSkinDarkSide"
#pragma link "dxSkinDevExpressDarkStyle"
#pragma link "dxSkinDevExpressStyle"
#pragma link "dxSkinFoggy"
#pragma link "dxSkinGlassOceans"
#pragma link "dxSkinHighContrast"
#pragma link "dxSkiniMaginary"
#pragma link "dxSkinLilian"
#pragma link "dxSkinLiquidSky"
#pragma link "dxSkinLondonLiquidSky"
#pragma link "dxSkinMcSkin"
#pragma link "dxSkinMetropolis"
#pragma link "dxSkinMetropolisDark"
#pragma link "dxSkinMoneyTwins"
#pragma link "dxSkinOffice2007Black"
#pragma link "dxSkinOffice2007Blue"
#pragma link "dxSkinOffice2007Green"
#pragma link "dxSkinOffice2007Pink"
#pragma link "dxSkinOffice2007Silver"
#pragma link "dxSkinOffice2010Black"
#pragma link "dxSkinOffice2010Blue"
#pragma link "dxSkinOffice2010Silver"
#pragma link "dxSkinOffice2013DarkGray"
#pragma link "dxSkinOffice2013LightGray"
#pragma link "dxSkinOffice2013White"
#pragma link "dxSkinPumpkin"
#pragma link "dxSkinsCore"
#pragma link "dxSkinsDefaultPainters"
#pragma link "dxSkinSeven"
#pragma link "dxSkinSevenClassic"
#pragma link "dxSkinSharp"
#pragma link "dxSkinSharpPlus"
#pragma link "dxSkinSilver"
#pragma link "dxSkinSpringTime"
#pragma link "dxSkinStardust"
#pragma link "dxSkinSummer2008"
#pragma link "dxSkinTheAsphaltWorld"
#pragma link "dxSkinValentine"
#pragma link "dxSkinVisualStudio2013Blue"
#pragma link "dxSkinVisualStudio2013Dark"
#pragma link "dxSkinVisualStudio2013Light"
#pragma link "dxSkinVS2010"
#pragma link "dxSkinWhiteprint"
#pragma link "dxSkinXmas2008Blue"
#pragma link "dxGDIPlusClasses"
#pragma link "cxClasses"
#pragma link "cxControls"
#pragma link "dxRibbon"
#pragma link "dxRibbonCustomizationForm"
#pragma link "dxRibbonSkins"
#pragma link "dxSkinsdxRibbonPainter"
#pragma link "dxBar"
#pragma link "dxSkinsdxBarPainter"
#pragma link "cxContainer"
#pragma link "cxEdit"
#pragma link "cxImage"
#pragma link "cxCustomData"
#pragma link "cxData"
#pragma link "cxDataStorage"
#pragma link "cxDBData"
#pragma link "cxFilter"
#pragma link "cxGrid"
#pragma link "cxGridCustomTableView"
#pragma link "cxGridCustomView"
#pragma link "cxGridDBTableView"
#pragma link "cxGridLevel"
#pragma link "cxGridTableView"
#pragma link "cxNavigator"
#pragma link "cxStyles"
#pragma link "dxSkinscxPCPainter"
#pragma resource "*.dfm"
TMainF *MainF;
//---------------------------------------------------------------------------
__fastcall TMainF::TMainF(TComponent* Owner)
	: TForm(Owner)
{
	iExit=0, iLogin=1, iLogout=2;
}
//---------------------------------------------------------------------------
__fastcall TMainF::~TMainF()
{
	delete StockGridF	;
	delete ReceiveGridF	;
	delete ReleaseGridF	;
	delete UsageGridF	;
	delete RepairGridF	;
	delete TempleGridF	;
	delete ItemGridF    ;
	delete UserGridF    ;
}
//---------------------------------------------------------------------------
void __fastcall TMainF::cxButton1Click(TObject *Sender)
{
	*p_iExit = iExit;
	MainF->Close();
//	ModalResult = mrOk;
}
//---------------------------------------------------------------------------
void __fastcall TMainF::cxButton2Click(TObject *Sender)
{
	if(WindowState == wsNormal){
		MainF->WindowState = wsMaximized;
		cxButton2->OptionsImage->ImageIndex = 1;
	}else{
		MainF->WindowState = wsNormal;
		cxButton2->OptionsImage->ImageIndex = 2;
	}
}
//---------------------------------------------------------------------------
void __fastcall TMainF::cxButton3Click(TObject *Sender)
{
	MainF->WindowState = wsMinimized;
}
//---------------------------------------------------------------------------
//	�� �巡�� ���
void __fastcall TMainF::Panel1MouseMove(TObject *Sender, TShiftState Shift, int X,
          int Y)
{
	ReleaseCapture();
	MainF->Perform(WM_SYSCOMMAND, 0xf012,0);
}
//---------------------------------------------------------------------------
// ���� Resizeable �ϰ� ����� �ڵ�(��� �����κ� ��� �ٰ� ����� ��������.)
void __fastcall TMainF::CreateParams(TCreateParams& Params)
{
	TForm::CreateParams(Params);
	Params.Style = WS_POPUP | WS_THICKFRAME;
}
//---------------------------------------------------------------------------
// ��� ���� ��� �� �κ��� ���ִ� �ڵ�(����� ȣ��� ����� Ŭ���� �ȵǴ� ��������.)
// WndProc virtual method override
//void __fastcall TForm1::WndProc(TMessage &M)
//{
//  static RECT rect = {0};
//
//  switch (M.Msg)
//  {
//  case WM_CREATE:
//	  AdjustWindowRectEx(&rect, GetWindowLongPtr(Handle, GWL_STYLE) & ~WS_CAPTION, FALSE, NULL);
//	  rect.left *= -1;
//	  rect.top *= -1;
//	  return;
//
//  case WM_NCACTIVATE:
//	  return;
//
//  case WM_NCCALCSIZE:
//	  if (M.LParam)
//	  {
//		  NCCALCSIZE_PARAMS* sz = (NCCALCSIZE_PARAMS*)M.LParam;
//		  sz->rgrc[0].top += 3; //��� ������ ������ ���ַ��� �ڸ�Ʈ ó��
//		  sz->rgrc[0].left += rect.left;
//		  sz->rgrc[0].right -= rect.right;
//		  sz->rgrc[0].bottom -= rect.bottom;
//		  return;
//	  }
//	  break;
//
//  default:
//	  TForm::WndProc(M);
//  }
//}//---------------------------------------------------------------------------
void __fastcall TMainF::Panel1DblClick(TObject *Sender)
{
	if(WindowState == wsNormal){
		MainF->WindowState = wsMaximized;
		cxButton2->OptionsImage->ImageIndex = 1;
	}else{
		MainF->WindowState = wsNormal;
		cxButton2->OptionsImage->ImageIndex = 2;
	}
}
//---------------------------------------------------------------------------
void __fastcall TMainF::btItemRegClick(TObject *Sender)
{
	if(ItemF == NULL){
		ItemF = new TItemF(NULL);
	}

	if(ItemF->ShowModal() == mrOk){
		ShowMessage("OK");
	}else{
		ShowMessage("Cancel");
	}

	delete ItemF;

}
//---------------------------------------------------------------------------

void __fastcall TMainF::FormClose(TObject *Sender, TCloseAction &Action)
{
	Action = caFree;
}
//---------------------------------------------------------------------------

void __fastcall TMainF::FormDestroy(TObject *Sender)
{
	MainF = NULL;
}
//---------------------------------------------------------------------------



void __fastcall TMainF::dxBarLargeButton10Click(TObject *Sender)
{
	if(StockGridF == NULL){
		StockGridF = new TStockGridF(pnMain);
		StockGridF->Parent = pnMain;
		StockGridF->Align = alClient;
		StockGridF->Show();
	}else{
		StockGridF->Parent = pnMain;
		StockGridF->Align = alClient;
		StockGridF->Show();
	}

}
//---------------------------------------------------------------------------

void __fastcall TMainF::dxBarLargeButton13Click(TObject *Sender)
{
	if(ReceiveGridF == NULL){
    	ReceiveGridF = new TReceiveGridF(pnMain);
		ReceiveGridF->Parent = pnMain;
		ReceiveGridF->Align = alClient;
		ReceiveGridF->Show();
	}else{
		ReceiveGridF->Parent = pnMain;
		ReceiveGridF->Align = alClient;
		ReceiveGridF->Show();
	}

}
//---------------------------------------------------------------------------

void __fastcall TMainF::dxBarLargeButton14Click(TObject *Sender)
{
	if(ReleaseGridF == NULL){
		ReleaseGridF = new TReleaseGridF(pnMain);
		ReleaseGridF->Parent = pnMain;
		ReleaseGridF->Align = alClient;
		ReleaseGridF->Show();
	}else{
		ReleaseGridF->Parent = pnMain;
		ReleaseGridF->Align = alClient;
		ReleaseGridF->Show();
	}

}
//---------------------------------------------------------------------------

void __fastcall TMainF::dxBarLargeButton15Click(TObject *Sender)
{
	if(UsageGridF == NULL){
		UsageGridF = new TUsageGridF(pnMain);
		UsageGridF->Parent = pnMain;
		UsageGridF->Align = alClient;
		UsageGridF->Show();
	}else{
    	UsageGridF->Parent = pnMain;
		UsageGridF->Align = alClient;
		UsageGridF->Show();
	}
}
//---------------------------------------------------------------------------

void __fastcall TMainF::dxBarLargeButton16Click(TObject *Sender)
{
	if(RepairGridF == NULL){
		RepairGridF = new TRepairGridF(pnMain);
		RepairGridF->Parent = pnMain;
		RepairGridF->Align = alClient;
		RepairGridF->Show();
	}else{
		RepairGridF->Parent = pnMain;
		RepairGridF->Align = alClient;
		RepairGridF->Show();
	}

}
//---------------------------------------------------------------------------

void __fastcall TMainF::dxBarLargeButton17Click(TObject *Sender)
{
	if(TempleGridF == NULL){
		TempleGridF = new TTempleGridF(pnMain);
		TempleGridF->Parent = pnMain;
		TempleGridF->Align = alClient;
		TempleGridF->Show();
	}else{
		TempleGridF->Parent = pnMain;
		TempleGridF->Align = alClient;
		TempleGridF->Show();
	}


}
//---------------------------------------------------------------------------

void __fastcall TMainF::dxBarLargeButton19Click(TObject *Sender)
{
	if(ItemGridF == NULL){
		ItemGridF = new TItemGridF(pnMain);
		ItemGridF->Parent = pnMain;
		ItemGridF->Align = alClient;
		ItemGridF->Show();
	}else{
		ItemGridF->Parent = pnMain;
		ItemGridF->Align = alClient;
		ItemGridF->Show();
	}
}
//---------------------------------------------------------------------------

void __fastcall TMainF::dxBarLargeButton20Click(TObject *Sender)
{
	if(UserGridF == NULL){
		UserGridF = new TUserGridF(pnMain);
		UserGridF->Parent = pnMain;
		UserGridF->Align = alClient;
		UserGridF->Show();
	}else{
		UserGridF->Parent = pnMain;
		UserGridF->Align = alClient;
		UserGridF->Show();
	}

}
//---------------------------------------------------------------------------
void __fastcall TMainF::btLogoutClick(TObject *Sender)
{
	*p_iExit = iLogout;
	MainF->Close();
}
//---------------------------------------------------------------------------

