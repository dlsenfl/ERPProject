//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
#include <tchar.h>
//---------------------------------------------------------------------------
#include <Vcl.Styles.hpp>
#include <Vcl.Themes.hpp>
USEFORM("FormGridU\UsageGridU.cpp", UsageGridF);
USEFORM("FormGridU\TempleGridU.cpp", TempleGridF);
USEFORM("FormGridU\StockGridU.cpp", StockGridF);
USEFORM("FormGridU\UserGridU.cpp", UserGridF);
USEFORM("RegisterU\ItemU.cpp", ItemF);
USEFORM("MainU.cpp", MainF);
USEFORM("LoginU.cpp", LoginF);
USEFORM("FormGridU\ItemGridU.cpp", ItemGridF);
USEFORM("FormGridU\RepairGridU.cpp", RepairGridF);
USEFORM("FormGridU\ReleaseGridU.cpp", ReleaseGridF);
USEFORM("FormGridU\ReceiveGridU.cpp", ReceiveGridF);
USEFORM("RegisterU\UserU.cpp", UserF);
//---------------------------------------------------------------------------
int WINAPI _tWinMain(HINSTANCE, HINSTANCE, LPTSTR, int)
{
	try
	{
		Application->Initialize();
		Application->MainFormOnTaskBar = true;
		Application->CreateForm(__classid(TUserF), &UserF);
		Application->Run();
	}
	catch (Exception &exception)
	{
		Application->ShowException(&exception);
	}
	catch (...)
	{
		try
		{
			throw Exception("");
		}
		catch (Exception &exception)
		{
			Application->ShowException(&exception);
		}
	}
	return 0;
}
//---------------------------------------------------------------------------
